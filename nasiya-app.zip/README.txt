Mini CRM — Nasiya & Tölovlar (PWA)
====================================

Qanday ishlatish:
1) Arxivni oching va `index.html` faylini brauzerda ishga tushiring.
2) Mijoz qo‘shing, keyin har bir mijoz uchun **Qarz** yoki **Tölov** tranzaksiyalarini qo‘shing.
3) Yuqoridagi kartochkalarda jami **Qarz**, **Qaytgan**, **Qoldiq** avtomatik hisoblanadi.
4) Maʼlumotlarni saqlash brauzerning `localStorage`ida. Xohlasangiz `Eksport/Import` orqali zaxiralang.
5) PWA sifatida o‘rnatish uchun: brauzerda “Add to Home Screen / Uy ekraniga qo‘shish” ni tanlang.

Tavsiyalar:
- Telefon raqamini +998 formatida yozing.
- Jadvaldan mijozni “Ko‘rish” orqali tranzaksiyalarni boshqaring.
- “O‘chirish” butoni mijoz yoki tranzaksiyani butunlay olib tashlaydi.
